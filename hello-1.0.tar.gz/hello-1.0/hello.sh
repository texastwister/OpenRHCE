#!/bin/bash
#hello.sh
echo "hello"
exit 0

